# sets the pillars required for commencement to 2 
umm ,..,  <br>
it literally just does that .,,..,.,,.,<br>
made because to my knowledge there isnt a mod that does this standalone from [risky mod](https://thunderstore.io/package/Risky_Lives/RiskyMod/) and i dont like doing 4 pillar s,.,.,.,.,,,,.,,,.,,,,.,.,.,.,<br><br><br><br><br><br><br><br>
oh and also youcan configure it i guess ,,.

![pov me not doing 4 pillars   !! ](https://media1.tenor.com/m/hm7-qu4T9vEAAAAd/marisa-kirisame-temmerson.gif "yay !!! yippie !!!!!!!!! wahooo !!!!!!!!!!!!!!!!!! ")

